import cv2

image = cv2.imread("cv.png")

if image is None:
    print("Oops! Your image is not working")
else:
    print("Image Loaded Successfully")
    cv2.putText(image, "Hello Python Programers", (50, 500),
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 0, 0), 2)
   

    cv2.imshow("Adding text over image", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()